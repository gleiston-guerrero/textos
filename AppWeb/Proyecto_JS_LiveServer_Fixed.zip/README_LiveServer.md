# Ejecutar con Live Server (VS Code)

1. Instale la extensión **Live Server** de Ritwick Dey en VS Code.
2. Abra esta carpeta (`js_project_fixed`) en VS Code.
3. Haga clic derecho sobre **index.html** y elija **Open with Live Server**.
4. El navegador se abrirá en `http://127.0.0.1:5500` (o similar).

> Nota: Si movió archivos, asegúrese de que las rutas en `index.html` usen rutas **relativas** (./, sin backslashes).
