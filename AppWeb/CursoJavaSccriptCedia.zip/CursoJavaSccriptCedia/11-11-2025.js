<script>
    console.log("Mensaje de prueba");
    alert("¡Hola Mundo!");
    let result = prompt("Ingrese su nombre: ");
</script>